# v107 Review
## Scope
Packages the complete accumulated numerical research from v081-v106.
## Inherited verified results
- 48/48 bank identity
- 576/576 probes
- 5040 comparisons with correct channel routing
- 852/852 decomposition
- 1680 radius + 1680 perturbation
- 576 period diagnostics + 14400 components
## v106 findings
- v106 status/review used old schema
- v106 did not include full 5040 independent verification or oracle fixes
- These are delivery scope gaps, not numerical errors
## Not claimed
No diameter, causality, detectability, or identifiability claims.

# v108 Review
## Scope
V108_FULL_FROZEN_RELEASE: v107 audit, evidence-level inheritance, complete numerical acceptance, real archive.
Source: v107 fixed commit bc699b0932cf18f5abad10e09f1d1eae0f29446e (parent v106 79ba7a7f9068b6ed3a0c621eb25be488de85e68c).
Production entry: tools/run_v108_all.py (tool SHA-256 recorded in status.json). All outputs written outside the source tree; the real ZIP carries the 73 core inputs, tool snapshot, stage logs and all numeric results.
## Machine gates (this run, all PASS)
- A: 73/73 snapshots byte-verified; 48/48 bank identity (C=2X/(N*Imean) <1e-10, mask formula); 24/24 old-C160 rF <1e-10; probe NPZ git blob 6b180147f64847329375363d44c317b2d4df247b, 192 keys exact.
- B: 14400/14400 three-frequency three-path origins (6 complex diffs each <1e-11) + independent subprocess FFT 14400/14400; 576/576 probe gates; 576/576 zero-start; 192/192 periods; 24/24 motion-time pairings; 576 amp summaries; 14400 projection components.
- C: 5040/5040 independent decisions match production <1e-12 (per-channel squared-sum reduction; total norms NOT replaced by per-channel norms); 210 summaries; 1440-row and 60-summary historical subsets verified as strict key subsets; 19/19 error tests through the real validation entry (duplicate/extra keys now detected; order-insensitive positives accepted; old v105 13/19 kept as historical fact).
- D: 852/852 decompositions (both identity residuals <1e-12); 2556 channel terms; 180 single-160 fixed-control items; 1680 radii + 70 summaries + 1680 budgets derived from the independently verified decision (m>0 AND no cross-D tie; eps_q<m/2, symmetric<m/4, eta<m/8); v103/v104/v105 tables re-audited REUSED_VALUES_AUDITED_CURRENTLY; v106-rewritten v096 radius values read at the current fixed commit and matched <1e-12; v107 status/receipt audited as historical facts (receipt zip_status=PENDING_CREATION; status hash claim mismatch), never copied as v108 evidence.
## Archive
Real ZIP sha256 47ab8c14028997c56f180d44efeead0f22de2e7b54b3274b44b080b5938fcbab; external receipt, launch record and v108_archive_check.json produced by tools/v108_archive_check.py re-reading ZIP bytes (CRC, member set, per-member SHA, 73 roles/cases, status hash, machine gates). Result: ARCHIVE_VERIFIED, NUMERICAL_SEALED, exit 0.
## Not claimed
No new BEM/render/optics/physics/experiment reads (0/0/0/0/0). calibration_valid, experimental_validation, detection_validated remain false; single_particle_diameter NOT_ESTIMATED; physics admission PENDING_PARAMETERS; rule7 new authorizations 0.

# v109 Review
## Scope
V109_DELTA_REPAIR_AND_PHYSICS_ADMISSION. Delta acceptance of frozen v108 (source commit e377f8a11421a04bc3e6c1eaca9f435a46566784, parent v107 bc699b0932cf18f5abad10e09f1d1eae0f29446e). Production entry tools/run_v109_delta.py; outputs outside the source tree; real ZIP + external receipt/launch/archive_check.
## Machine gates (all PASS -> DELTA_VERIFIED)
- A: fixed HEAD verified; 73/73 byte snapshots (SHA vs git manifest where listed; probe git blob 6b180147...); 14400/14400 origin readback (six diffs <1e-11 recomputed from stored A/B/C) + per-frequency FFT from saved series 14400/14400; mean identity 4800/4800; 576/576 zero-start; 576/576 probe readbacks; periods/pairs/components reused by SHA+gates; v107 status LF/CRLF dual fingerprint verified with explicit hash_domain (git canonical blob bf16131f... == LF; 2594b2b7.../8007700d... == LF->CRLF conversion; content identical, neither is tampering); v108 ZIP bytes independently re-verified (SHA 47ab8c14...).
- B: genuinely independent decision SUBPROCESS: 5040/5040 match vs v108 frozen table <1e-12; 210 summaries; 1440/60 strict subsets (keys + values + counts; sub1440_field_bad=0; s60 dup keys=0); 23/23 error tests through the real validation entry incl. nearest_dist/second_dist/final_decision/tie_threshold injections and EXACT-threshold rejection (diff == 1e-12 rejected under strict <1e-12); row-order reversal accepted.
- C: corrected 180-row count control (6 channel subsets x 10 groups x 3 features, bin-160 baseline; 85 rows with count change; all outcomes kept, no selection); 60-pair factor-distance table repaired: corrected d3 (single total-norm normalization) matches joint unit-shape direct distance from 852 decomposition with max residual 6.7e-16; 60/60 d3 changed, max |delta| 3.146 (formula correction, NOT multi-frequency gain); d1/d2 unchanged; 852/852 decomposition residuals <1e-12; 1680 radii + 70 summaries + 1680 budgets (m>0 AND no cross-D tie).
- D: physics_input_contract.json (15 items: 4 measured with file/line provenance, 3 assumed, 8 missing=null) + two bounded route designs (trajectory-first; field-first); design only, no new solves; 65nm demo pixel and 5-20nm amplitudes remain assumptions.
## Archive
Real ZIP sha256 6d4535903f8a2f89c064e35f4c918810e13b9cc5fe0dc6d275a29ab7e10a7a2d; single final ZIP built after status+final_summary; external checker verifies CRC, unique members, full manifest, 73 roles with EXACT case multiset, per-member SHA, status task/source/gates (exact fixed gate set, strict booleans); archive_integrity and numerical_accepted recorded separately. Result: DELTA_VERIFIED, ARCHIVE_VERIFIED, exit 0.
## Not claimed
0 new BEM/render/optical-time-series/physics-states/experiment-video reads. Frozen states unchanged; physics admission PENDING_PARAMETERS; rule7 new authorizations 0.

# v110 Review
## Scope
V110: v109 fixed-commit review, delta numerical evidence sealing, archive consistency, real physics admission. Source frozen at 3f894b919d11dd2e8dead92b83ed7ec2d930d08c (parent v108 e377f8a...). Production entry tools/run_v110_all.py; outputs outside the tree; two-phase archive protocol (provisional selftest fixture -> single final ZIP after verifier qualification; both hashes disclosed in logs/v110_provisional_zip_sha.json).
## Machine gates (all PASS)
- A: fixed HEAD/parent verified; 73/73 snapshots (manifest SHA cross-check; probe blob 6b180147...); v109 ZIP bytes independently re-verified (6d453590...); v108 ZIP re-verified (47ab8c14...); v107 LF/CRLF dual fingerprint confirmed with explicit hash_domain; source diff vs v109 saved (logs/v110_source_diff.patch).
- B: independent decision subprocess 5040/5040 vs frozen v109 table AND v108 table (<1e-12, all fields; v108 absent fields counted NOT_RECORDED, never invented); 210 summaries match; 1440/60 strict subsets; 23/23 error tests through the released validation entry incl. exact-threshold rejection and order-reversal acceptance.
- C: count-control audit 180/180 against the accepted 210 (78 increased / 95 unchanged / 7 decreased; ambiguity preserved, no selection); 60/60 corrected d3 match decomposition <1e-12; 120/120 d1/d2 unchanged; corrected 180-row table carries target_feature_diff NA semantics; 30-group difference attribution: all 60 historical v092 summary rows REPRODUCE EXACTLY under the v092 representation definition with complex128 arrays - the 30 reported differences are three_bin_magnitude rows compared against a single-160 baseline (PROVEN statistical-object difference); C400_only rows equal current bin160 counts exactly; single-precision attribution NOT supported by evidence.
- D: 14400/14400 origin readback (six diffs <1e-11) + per-frequency FFT from saved series; 576/576 zero-start; 576/576 probes; periods/pairs/components reused by SHA+gates; 852/852 decomposition; 1680 radii + 1680 budgets with m>0 AND no-cross-D-tie qualification checked per row; consistent with frozen v109 tables <1e-12.
- E: physics contract reclassified into USER_CONFIRMED / EXPERIMENT_SCRIPT_RECORDED / ANALYSIS_CONTRACT / SIMULATION_ASSUMPTION / MISSING; k0 bins are ANALYSIS_CONTRACT (INSTRUMENT_MEASURED rejected by contract validator); Fs script-recorded only (no clock calibration); 520nm USER_CONFIRMED without instrument certificate; source audit reads each cited file/line (7 VERIFIED, 8 NO_SOURCE_AS_DECLARED); GO=false for both routes -> REAL_PHYSICS_PENDING_INPUTS with formal prerequisites (independent diameter calibration/blank, B-off control, camera time sync).
- F: released v110 verifier self-test 11/11: missing ZIP (v109 finish(ok=True) defect fixed), missing BANK case, duplicate member, corrupt CRC, manifest path traversal, status missing, string-bool gates, missing gate, wrong task id, wrong status SHA all rejected with non-zero exit; positive control mechanically integral. archive_integrity and numerical_accepted recorded separately.
## Archive
Final ZIP sha256 0c8a21116170c26cef59d2446f7fe2e9598babae97df18e171aa343585aadeb8; in-ZIP status explicitly PRE_ARCHIVE_VERIFICATION; external receipt + post_archive_summary.json (sha recorded in receipt) are the only post-verification credentials. Result: DELTA_EVIDENCE_SEALED, ARCHIVE_VERIFIED, exit 0.
## Not claimed
0 new BEM/render/optical-time-series/physics-states/experiment-video reads; P0 remains OPEN; rule7 new authorizations 0; frozen states unchanged; no absolute single-particle diameter claim.

# v111 Review
## Scope
V111_TARGETED_AUDIT_AND_REAL_INPUT_READINESS. Source frozen at v110 4aa76ac1204d1133e2d53f9631a2f3fb3db7015d (parent v109 3f894b9...). Production entry tools/run_v111_all.py; helpers tools/audit_attribution.py (real run, not transcription) and tools/validate_decisions.py (full-table released validation entry).
## Machine gates (all PASS)
- A: fixed HEAD/parent verified; 73/73 byte snapshots; probe blob 6b180147...; v110 ZIP bytes independently re-verified (0c8a2111...); source diff vs v110 saved; historical attribution revision via REAL audit_attribution.py run: 30-row algebraic decomposition H-S=(H-M)+(M-S) identity holds for all 30; 28 nonzero totals, 2 zero totals (1 both-zero + 1 cancellation); revised 60-row explanation replaces blanket claims (no single-precision attribution, no 'all identical' claim); historical 6-cached-states C400 triple-copy defect reproduced but NOT endorsed.
- B: production table (5040 rows) audited through the FULL released validate_decisions.validate_table entry - 0 issues, both directions (worker cross-audited against frozen v110 records); duplicates/extra keys can no longer be masked by dict conversion; 23/23 injection tests via the same entry; 1440/210/60 subsets re-verified.
- C: real metadata provenance - both original extractor scripts (test.m, test_with_contrast.m) FOUND on workstation with SHA-256 matching recorded inventory (DIRECT_SCRIPT_HASH_VERIFIED); Fs=5000/N=2001 located to real script lines; contract v111 has 19 items with source_directness levels; exposure/gain/trigger/timestamps split into independent sub-fields; axial/orientation kept PENDING_CONSTRAINT (never defaulted to 0); missing_inputs_action_sheet.csv lists 12 open items with acquisition methods and blocked routes.
- D: observation operator interface (intensity-average model, explicit gain for electron counts, explicit time origin, non-uniform-timestamp refusal) + 8/8 pure-math fixtures pass; status SOFTWARE_INTERFACE_READY; REAL_PHYSICS_GO=false (separate from software readiness).
- F: released v111 verifier selftest 12/12 (incl. wrong-source-commit negative and mechanical/gate-class criteria).
## Archive
Final ZIP sha256 40b9476dc9ba1a3190137737dd89616ded76b97e9335bb604f998de5ae01e46a; two-phase protocol retained (provisional fixture hash disclosed); in-ZIP status PRE_ARCHIVE_VERIFICATION; external receipt + post_archive_summary.json hashed. Result: TARGETED_AUDIT_SEALED, ARCHIVE_VERIFIED, exit 0.
## Not claimed
0 new BEM/render/optical-time-series/physics-states/experiment-video reads; P0 OPEN; rule7=0; frozen states unchanged; no absolute diameter claim; original 48-state model formally sealed pending unchanged-repair confirmation.

# v112 Review
## Scope
V112_EXECUTABLE_OBSERVATION_OPERATOR_AND_SOURCE_ALIGNMENT. Source frozen at v111 24fbd6bbfe8b2dd503efbf093a09fc3a60371a30 (parent v110 4aa76ac...). Production entry tools/run_v112_all.py; new importable module tools/observation_operator.py + 12 fixed integration groups tools/observation_integration_tests.py.
## Machine gates (all PASS)
- A: fixed HEAD/parent; 73/73 byte snapshots (git-manifest cross-check); legacy 5040 field self-consistency scan (single read, no new distances): record_key/bins/group/query/feature correspondence, query metadata vs case name, near_min_set_size vs members, tie_across_D vs D-set, finite values, source SHA vs bank - 0 issues in 5040 rows -> LEGACY_48_STATE_BASELINE_FROZEN recorded; C400_only H/M/S components set NOT_APPLICABLE (export semantics only; the 30-row three-bin decomposition untouched); v111 ZIP bytes re-verified (40b9476d...).
- B: variable-level source verification: both extractor scripts SHA-verified on workstation; explicit encodings (test_with_contrast.m = UTF-8, test.m = GBK; strict decode, no replacement-char semantics); actual assignments located with context and classification (test_with_contrast.m: Fs=5000 L39, targetFreq=400 L42, startFrame=1000 L45, endFrame=3000 L46, meanFloorFraction=0.01 L60, timeMean=mean L218, fft L230, oneSidedScale L267/269 branch, validContrastMask L289; test.m: Fs L23, targetFreq=420 L26, frames L30/31); N=2001 recorded as DERIVED (not DIRECT_VARIABLE_VERIFIED); camera gain split into kappa_e_per_U_per_s / g_DN_per_e / offset_DN (all MISSING); 12 open inputs grouped optics/camera/sample_motion (missing_inputs_groups_v112.csv).
- C: executable observation operator: importable module with time contract (explicit meaning start/center/end, positive exposure, T=0 only in instantaneous_limit mode, strict-increase + difference-uniformity validation BEFORE any intensity callback), unit contract (Ibar -> mu_e = kappa*T*Ibar -> mu_DN = offset + g*mu_e, three output modes), complex-field callbacks rejected, DFT phase origin = first exposure center. 12/12 fixed integration groups pass through the actual module (grid accept/reject, constant-intensity window invariance, start/center same-window equivalence, three-bin analytic amplitude AND phase with sinc exposure attenuation, intensity-vs-field-average inequality + complex rejection, zero-exposure limits, linear exposure scaling with separate offset, six interface rejections, explicit pixel weights connected to the same exposure/DFT entry, exact-400Hz off-bin FFT vs independent DFT with leakage, joint-shift relative phase invariance, gain-cancels/offset-does-not + 32/64-node quadrature consistency).
- F: released v112 verifier selftest 12/12 (mechanical + gate-class negatives, positive control).
## Separated statuses
LEGACY_48_STATE_BASELINE_FROZEN | OBSERVATION_OPERATOR_TESTED_ON_FIXED_FIXTURES (fixed fixtures only, not arbitrary physical inputs) | REAL_DEVICE_FORWARD_GO=false | ABSOLUTE_DIAMETER_VALIDATION_GO=false (independent diameter reference/blank/uncertainty chain missing).
## Archive
Final ZIP sha256 7bcee33fccf8e30192917d9aa2e257d9eb1925c74c3d4f7dfe6df72118e45e45; two-phase protocol (provisional fixture hash disclosed); in-ZIP status PRE_ARCHIVE_VERIFICATION; external receipt + post_archive_summary hashed. Result: OBSERVATION_OPERATOR_SEALED, ARCHIVE_VERIFIED, exit 0.
## Not claimed
0 new BEM/render/optical-time-series/physics-states/experiment-video reads; P0 OPEN (block/unblock consistency item, not a model failure verdict); rule7=0; frozen states unchanged; no absolute diameter claim; no exposure/phase/frequency best-pick scanning.

# v113 Review
## Scope
V113_MEASUREMENT_OPERATOR_ORIGINAL_GATES_AND_INPUT_ADMISSION. Source frozen at v112 d11814c2e286a2e6a2195308923adc81406fa537 (parent v111 24fbd6b...). Production entry tools/run_v113_all.py; restored-gate module tools/observation_operator.py (v2); tests tools/observation_integration_tests_v113.py.
## Machine gates (all PASS)
- A: fixed HEAD/parent; 73/73 snapshots inherited (git-manifest cross-check); v112 ORIGINAL module/tests archived from the frozen commit with SHAs (failure facts preserved, not overwritten); v112 ZIP bytes re-verified (7bcee33f...).
- B: ORIGINAL gates restored - same-array X/C strictly <1e-11, mean identity <1e-12 (the v112 1e-9 patches removed); production path = real numpy.fft; independent path = direct DFT of the SAME stored array via (j*k)%N + math.fsum; three error classes separated (analytic closed-form residual ~1e-11..5e-11 REPORTED; callback float-time sample error 9.1e-14 RECORDED; same-array FFT/DFT residual ~1e-13/1e-14 GATED); module pre-validation hardened (NaN/negative Fs, NaN/negative tolerance, duplicates/reversal, non-finite/negative intensity, complex-field callbacks, NaN/negative kappa, negative/zero-sum/non-finite weights, invalid quadrature order, instantaneous flag requires exposure exactly 0); 12/12 groups + 4/4 bounded mutations (skip precheck, omit exposure factor, wrong bin, folded pixel axis) DETECTED; main run passed on first attempt (runs=1, no expectation changes).
- C: effective assignments/branch evidence: 12 DIRECT + 2 BRANCH_CONDITION_KNOWN (endFrame=totalFrames under `if isinf(endFrame)` NOT taken for endFrame=3000; oneSidedScale=2 under `if ~isDC && ~isNyquist` with odd 2001-frame selection); N=2001 kept DERIVED/conditional; EFFECTIVE_FOR_THIS_RUN=0 (no batch run metadata); script SHA + encoding recorded (utf-8/gbk), hash domains separated.
- D/F: four-layer admission (layer1 FROZEN, layer2 SOFTWARE_ORIGINAL_GATES_PASS, layer3 REAL_DEVICE_RELATIVE_FORWARD_GO=false with requirement list incl. permitted explicit fixed-exposure/linear/zero-offset normalized-C case, layer4 ABSOLUTE_COUNT_GO=false + ABSOLUTE_DIAMETER_VALIDATION_GO=false); verifier selftest 12/12; two-phase archive (provisional hash disclosed).
## Archive
Final ZIP sha256 4eda2aebe48aecc7c770bc7fb55a653db1e679278f4bf26e1d55a4d8dc77e0dd; in-ZIP status PRE_ARCHIVE_VERIFICATION; external receipt + post_archive_summary hashed. Result: ORIGINAL_GATES_RESTORED, ARCHIVE_VERIFIED, exit 0.
## Not claimed
0 new BEM/render/optical-time-series/physics-states/experiment-video reads; legacy re-verification 0 (5040/852/14400/1680 untouched); P0 OPEN; rule7=0; frozen states unchanged; no absolute diameter claim; original 48-state model sealed pending no further same-type rounds without real inputs.

# v114 Review
## Scope
V114_OPERATOR_GUARDRAILS_AND_SAVED_PROBE_BRIDGE. Source frozen at v113 89a5b353ba104a3dbf0764816933739f8edda33b (parent v112 d11814c...). Production entry tools/run_v114_all.py; new tools: v114_operator_gate_probe.py (17 guardrail tests), v114_saved_probe_bridge.py (576 read-only checks).
## Machine gates (all PASS)
- A: fixed HEAD/parent; 73/73 snapshots (git-manifest cross-check); probe blob 6b180147...; v113 ZIP bytes re-verified (4eda2aeb...); source diff vs v113 saved.
- B: red->green guardrail cycle - prepatch_red.json (12/20 on unmodified v113: fractional quadrature order silently truncated, quadrature 300 accepted, bool exposure, DN negative/NaN mu_e, count overflow, spectral gate failure exposed a certified dft, missing run_roi) archived with all failure facts; targeted fixes to tools/observation_operator.py (bool rejection, tolerance >= 0.5/Fs anti-alias bound with explicit non-clock-calibration note, quadrature order integer [2,256], empty/duplicate/illegal bins, mu_e/kappa/DN validation, count overflow, fail-closed spectral gates via SPECTRAL_GATE_FAIL_UNSEALED_PARTIAL, NaN arrays rejected, real timestamps never snapped); postpatch_green.json 20/20; original 12 groups + 4 mutations re-run on the v114 module: 12/12 + 4/4; G11 raw float sample error (9.1e-14) still recorded separately, never masked.
- C: 576/576 saved-probe read-only bridge: same stored float64 series through numpy FFT AND integer-remainder fsum direct DFT, both vs bank X[k,i,j]/C[k,i,j], all complex abs diffs < 1e-11; positive mean, dtype/finiteness, complete 192x3 unique key set; per-row source SHAs (probe NPZ + bank); scope honestly labeled (not 41x41 full-ROI validation, not new optical forwards).
- D: metadata readiness 16 items (value/unit/evidence_class/direct_source/source_sha256/valid_dataset/bounds/missing_acquisition); 520nm USER_CONFIRMED; Fs=5000 EXPERIMENT_SCRIPT_RECORDED (not calibrated clock); k0 ANALYSIS_CONTRACT; nominal_D=100nm NOMINAL_LABEL (not a certificate); 11 MISSING organized optics/camera/sample_motion; v113 effective-assignment table (12 DIRECT + 2 BRANCH) inherited.
- F: released v114 verifier selftest 12/12.
## Four-layer admission
LEGACY_SIMULATION_FROZEN | SOFTWARE_OPERATOR_CERTIFIED_FOR_FIXED_FIXTURES | REAL_DEVICE_RELATIVE_FORWARD_GO=false (11 listed blockers) | ABSOLUTE_COUNT_AND_DIAMETER_VALIDATION_GO=false. P0 OPEN; rule7=0; frozen states unchanged; next physics plans remain design-only (known-diameter standard first, B-off/blank control, ruler, held-out windows).
## Archive
Final ZIP sha256 a1e27cce70d44004393c83fa0efbaf42378c99caeea54e915468952a71b54aa4; two-phase protocol (provisional hash disclosed); in-ZIP status PRE_ARCHIVE_VERIFICATION; external receipt + post_archive_summary hashed. Result: GUARDRAILS_AND_BRIDGE_SEALED, ARCHIVE_VERIFIED, exit 0.
## Not claimed
0 new BEM/render/optical-time-series/physics-states/experiment-video reads; no 5040/852/14400/1680 recomputation; no absolute diameter, calibration curve, detection accuracy, or causal mechanism claims.

# v115 Review
## Scope
V115_ROI_MODE_AND_REGISTERED_SIMULATION_BRIDGE. Source frozen at v114 tip 7a9102d5f8c6f98305ed9b10279083de96be66e6 (v113 89a5b35... verified as ancestor). Production entry tools/run_v115_all.py; new tools: v115_operator_regression.py (27 tests, red->green), v115_saved_probe_bridge.py (576 checks through the production module).
## v114 production defects found and fixed (evidence: prepatch_red.json 21/27 on the unmodified v114 module)
- run_roi electron/dn modes silently emitted raw Ibar (unit conversion missing) -> fixed: mu_e = kappa_p*T*Ibar[p], mu_DN = offset_p + g_p*mu_e[p], scalar kappa/g/b broadcast to P (per-pixel calibration left for future explicit user data)
- run_roi called the intensity callback 2x per node + 1 probe (25601 calls vs 12800 expected) -> fixed: exactly ONE (P,Q) frame per quadrature node, validated once, row-normalized per pixel; T21 exact count 12800/12800
- static parameter errors leaked ordinary TypeError/ZeroDivisionError; k0s=[] silently expanded via `k0s or K0S` in compare_paths and bypassed in partial pipelines -> fixed: _validate_bins everywhere (None=default, explicit [] = EMPTY_BIN_LIST), zero-callback rejection for all statically checkable parameters, weighted_pixel_average([]) guarded, bool gain/offset rejected, NaN arrays rejected in both spectral paths
- callbacks returning wrong shapes leaked TypeError -> now specific CALLBACK_SHAPE OperatorError
## Machine gates (all PASS)
- A: HEAD == frozen v114 tip; v113 verified as ancestor; 73/73 snapshots; v114 ZIP bytes re-verified (a1e27cce...)
- B: 27/27 regression (postpatch_green); prepatch red 21/27 archived with all failure details; legacy suite on the v115 module 12/12 + mutations 4/4 (G11 raw float sample error still recorded separately)
- C: 576/576 saved-probe bridge THROUGH production_fft + independent_dft of tools/observation_operator.py on the same stored arrays vs bank X/C, gate <1e-11, dtype/finite/mean_positive/key-set in row PASS
- D: metadata readiness 16 items; four-layer admission; priority acquisition list (camera+optics -> sample+motion -> absolute counting/diameter)
- F: verifier selftest 12/12 (mechanical + gate-class negatives, positive control)
## Four-layer admission
LEGACY_SIMULATION_FROZEN | SOFTWARE_OPERATOR_CERTIFIED_FOR_FIXED_FIXTURES | REAL_DEVICE_RELATIVE_FORWARD_GO=false (11 blockers) | ABSOLUTE_COUNT_AND_DIAMETER_VALIDATION_GO=false. P0 OPEN; rule7=0; v115 auto-start physics count = 0.
## Archive
Final ZIP sha256 95eb681253afb54d2e846f341bce041f16f21293579f296f520050f7b03c5cab; two-phase protocol (provisional hash disclosed); Result: ROI_MODE_AND_BRIDGE_SEALED, ARCHIVE_VERIFIED, exit 0.
## Not claimed
0 new BEM/render/optical-time-series/physics-states/experiment-video reads; 0 recomputation of legacy statistics; no absolute diameter/calibration/detection claims; P=1681 remains an interface shape requirement, not generated time series.

# v116 Review
## Scope
v115 source forensics, production-boundary acceptance, saved-probe bridge re-verification, physics admission. Source frozen at v115 59800bae2a6b5c0b37531c09b6cc97158fad1d5f (v113 89a5b35... verified ancestor).
## Stage A forensics (GATE PASS on the clean v116 worktree)
- Raw git evidence saved (cat-file/rev-parse/merge-base/status/log + c1548ea8 fuller).
- RESOLVED: 1548ea810b9870251dc57e37ddec32ad8be68e42 = the MAIN v114 commit; the delivered v114 tip 7a9102d is the red-evidence addendum on top - so HEAD^ of the v115 tip is 1548ea8, NOT v113.
- ROOT CAUSE of the v115 A-gate failure: the first v115 driver checked HEAD^ == v113 directly (driver defect); the final v115 driver used the ancestor check. Same worktree, same HEAD 59800bae; Git history untouched.
- historical_v115_source_failure.json permanently records the delivered v115 zip (d435ca98...) status A=false/UNSEALED_PARTIAL/exit2 + the later green run (95eb6812...) as separate evidence; the v115 historical status is NOT rewritten to PASS.
- Three identities separated: fixed release branch / historical workstation run root / clean v116 re-verification worktree.
- 73/73 snapshots with git blob SHA-1, worktree SHA-256 (separate domains), review_inputs historical-copy comparison, full MAT content checks (C/X complex128, Imean float64, mask formula, N2001/Fs5000/bins, C=2X/(N*Imean) <1e-10).
## Stage B: 12 additional boundary tests, all PASS on the unmodified v115 module -> NO_PRODUCTION_PATCH_REQUIRED
- exact one-(P,Q)-frame-per-node sampling with stateful counter (no probe call); multi-pixel synchronized rows; scalar vs P=1,Q=1 equality; P=2,Q=3 no-mixing; P=1681 dimension fixture (partial grid, no expensive solve); electron scalar/vector broadcast; dn per-pixel b/g; intensity mode needs no gain; T=0 count rejection; unified OperatorError static rejects at zero callbacks; fail-closed per-pixel spectral gates.
- Legacy suite on the v116 module: 12/12 groups + 4/4 mutations.
## Stage C: 576/576 saved-probe bridge re-run through production_fft + independent_dft vs bank X/C (gate <1e-11), fresh evidence.
## Stage D: metadata 16 items (11 MISSING, prioritized optics/camera/sample_motion/count-diameter); five-layer admission: LEGACY_NUMERICAL_FROZEN | SOFTWARE_OPERATOR_FIXED_FIXTURES=CERTIFIED | REAL_DEVICE_RELATIVE_FORWARD_GO=false | ABSOLUTE_COUNT_GO=false | ABSOLUTE_DIAMETER_VALIDATION_GO=false; bounded pilot design (step 1: scale+exposure+B-off/blank/known-D standard; step 2: max 2 physics pilots only after inputs; v116 auto-physics-solves=0).
## Stage F: verifier selftest 12/12.
## Archive
Final ZIP sha256 e8a4d8cbe327c503f8871b4750a11542fb97ee8ab68819a92f3589365f981f50; two-phase protocol; Result: SOURCE_FORENSICS_AND_ACCEPTANCE_SEALED, ARCHIVE_VERIFIED, exit 0.
## Not claimed
0 new BEM/render/optical-time-series/physics-states/experiment-video reads; no legacy recomputation; P0 OPEN; rule7=0; frozen states unchanged; no absolute diameter claim.

# v117 Review
## Scope
V117_TARGETED_ACCEPTANCE_REPAIR_AND_PHYSICAL_INPUT_CONTRACT per the independent V116 review. Three identities separated: base source commit ae7f4797... (clean tree, porcelain empty during execution), execution code OUTSIDE the source tree (execution_code_manifest.json), release commit recorded on branch v117.
## S1 source acceptance (GATE PASS + 5/5 negative controls detected)
- Clean tree required and verified; all git commands succeed; exact 73 roles/cases; per-file worktree SHA-256 + git blob + length vs fixed tree; review_inputs mapping mismatches are FAILURES; full BANK content checks (dtypes, shapes, finite, N/Fs/bins/case, rebuilt 1%-median mask EXACT match, C identity <1e-10 with full-precision residual = 0); unreadable/corrupt bank files yield gate=false with reason (never crash).
- Negative controls (small source-tree-outside replicas, all DETECTED): wrong bytes, review_inputs copy mismatch, wrong mask, wrong dtype, wrong case identity.
## S2 operator repairs and regression (GATE PASS)
- T11 boolean-unpack bug fixed (per-case entry/error-type/callback-count records; aggregate over real booleans); two mandatory mutations (silent return, TypeError leak) DETECTED.
- Shared static pre-validation in BOTH entries: kappa/g/b/exposure/bins/time/weights validated with unified real-number rules (bool/complex/str/non-finite rejected; numpy reals accepted) BEFORE the first callback; callback exceptions wrapped in stable OperatorError with raise-from and time/stage; finiteness/non-negativity of converted series/mean verified before ANY partial/full return; ROI spatial_weights shape errors unified; overflow explicit.
- Regression on the repaired execution module: 27/27 production regression, legacy 12/12 groups + 4/4 mutations, v116 boundary 12/12 + 2/2 mutations. G11 float-time residual still recorded separately from same-array gates.
## S3 bridge (GATE PASS)
576/576 through production_fft + independent_dft on the SAME stored arrays vs bank X/C (<1e-11 each) PLUS the two NEW explicit gates folded into row PASS: same-array FFT-DFT <1e-11 and saved-series mean vs bank Imean_map <1e-12.
## S4 semantic admission (GATE PASS)
18 items with stable IDs and explicit fields; three D concepts separated (demo bank labels / 7.29 nominal 100nm / independent reference); route logic A OR B; relative-C branch not blocked solely by missing absolute kappa/g (bias/nonlinearity declared); statuses: METADATA_SCHEMA_VALID=true, CONDITIONAL_MODEL_DESIGN_READY=true, REAL_DEVICE_RELATIVE_FORWARD_GO=false, ABSOLUTE_COUNT_GO=false, ABSOLUTE_DIAMETER_VALIDATION_GO=false. missing_inputs_action_sheet.csv lists 14 missing records with acquisition methods.
## S5 archive + V116 verification
V116 original final ZIP (e8a4d8cb...) FOUND and hash-verified on this workstation -> V116_ARCHIVE_VERIFIED (clears the earlier UNVERIFIED flag without rebuilding anything). Final v117 ZIP sha256 a56eea50eb6e2b1787ec4f18ea2fc28ff998c6626bcfebc0bca01d80247eec0d; two-phase protocol; archive_integrity/numerical_accepted/archive_valid read separately from the checker JSON.
## Not claimed
0 new BEM/render/optical-time-series/physics-states/experiment-video reads; 0 legacy recomputation; P0 OPEN; rule7=0; two physics pilots are DESIGN_ONLY with auto_physics_solves=0; no absolute diameter claim; same-type acceptance loops end here - next progress comes from real inputs and the bounded pilots.
# v119 Review
## Scope
V119_CONTINUOUS_LOCAL_MODEL_AND_PILOT. Source frozen at v117 bbd0387 (v118 NOT_OBTAINED). Material convention finding: upstream NANOBEM uses exp(-i omega t), confirmed from ce49f77 source. Bridge 576/576 INHERITED. BEM-dependent stages BLOCKED (0/16 solves, 0/216 renders). Analytic exposure model delivered. Two DESIGN_ONLY pilots registered.
## Completed
- v117 baseline verification (all gates pass, exit=0)
- Material convention: UPSTREAM_CONVENTION_CONFIRMED
- Analytic exposure sinc table for 50/100/200us at 200/400/800Hz
- Bridge INHERITED (functions and inputs unchanged)
- BEM-dependent stages honestly marked BLOCKED
- Four-layer admission maintained (all forward GO=false)
## BLOCKED
- New BEM solves (0/16)
- Renders (0/216)
- New observations (0/64)
- Local D response 5-point (0/5)
- Holdout D (0/2)
- Perturbation projections (partial: analytic derivations only)
## Not claimed
P0 OPEN; rule7=0; calibration/experimental/detection=false; single_particle_diameter=NOT_ESTIMATED; no absolute diameter claim.
