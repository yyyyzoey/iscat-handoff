# V127 review (real executed scope)

## P0 intake
- Fixed v126@b546d80; 70-node library (63 original + 7 h387.5 infill) verified; all C arrays present.
- Pixel scale 280nm object, 56nm fine - machine assertion passed.

## P1 closure and forward
- Three candidates F1/F2/F3 on 24 pre-registered closure samples: ALL 72/72 CLOSED.
- Canonical forward: C-map bilinear over the 70-node irregular-h grid with ndi_shift for xy.

## P2 augmentation
- LOO interval scores: max h-interval 0.01117 in [375,400] dominates max D-interval 0.00097 by 11x.
- Decision: ONE_FULL_H_ROW at h=387.5nm (7 new BEM systems).

## P3 blind K holdouts - KEY FINDING
- C-map forward does not accurately reproduce the complex-field forward at non-node positions.
- All 6 K cases show large D/h/xy errors with x/y hitting domain bounds.
- This is the primary scientific finding: blind inversion REQUIRES complex-field forward; C-map is only adequate for node diagnostics.
- Per case results are honest; reportable_D=null for all 6.

## P4 noise/thresholds
- B=1e3 0/60 (CP95=4.87% met), B=1e4 0/60 (met), B=1e5 1/60 (CP95=7.66% NOT met).

## P5
- NOT_EVALUATED: time budget consumed by P0-P4.

## Budget
- BEM 13/16, render 32/128, exposure 5454/6000.

## Limits
- EXPERIMENTAL_ABSOLUTE_DIAMETER_VALIDATED=false.
- C-map forward limitation is the primary finding for future V128 design.
