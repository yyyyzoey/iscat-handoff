# ISCAT V166 返回包（iscat_v166_return_001.zip）

生成时间（UTC）：2026-10-28T10:51:43.532415+00:00

本包是**执行证据交付**，不是科学验收结论。pytest 全绿、`LEDGER_AND_ARTIFACT_BINDING_VERIFIED`、进程退出码 0 都只是机械状态，不等于粒径结论成立。全部 28 个任务的 `reportable_D` 均为 `null`，本包不提供任何绝对磁芯直径测量值。

## 1. 代码与提交

- 执行时代码 commit（P0-P5e 全部证据在此代码下产生）：`af2078b2a2d545b8455b48d814faa12017e5e8ac`
- P5f 结果 commit（执行证据入库）：`fffe580f4fd8e3bd224dc9bcadf478679ce3fdfc`
- P5f addendum commit（HEAD，补归档第 6 份修复 diff 并重生成结果清单）：`f5e88ad409baf50fd0a9cb6c44bc30b34a7b8a08`
- HEAD 受版本控制的 `results/v166/` 共 5139 个文件；`results/v165/` 的 3 个真值与 validator-only 评分文件只存在于磁盘与本包内，未写入 git 树，以免出现在估计器可引用的依赖路径中；`results_full` 清单按磁盘全量登记，两者口径不同
- V165 远端 HEAD（本轮起点，仅提交证据总结）：`bbe854c3a8c0427debc40f182fab64368de9ae23`
- 分支 `v166` 仅存在于本工作站，**未执行 push**

## 2. 阶段执行状态

| 阶段 | 状态 | 位置 / 事实 |
|---|---|---|
| P0 现场保护 | DONE | 只读快照 `C:\iscat\v166_p0\uncommitted`（110 个文件、原始 SHA 全部登记）；与当前树逐项比对 IDENTICAL 23 / MODIFIED 6 / SNAPSHOT_ONLY 81；其中 20 个源码+测试文件单列 |
| P1 修复三项测试失败 | DONE | 修复前 3 failed / 26 passed；修复后 production_001：41 collected、123 条结果全部 passed、exitstatus 0 |
| P2 最终 Gate A + preflight | DONE | `gate_a_003` PASS（历史 `gate_a_002` 未被复用）；preflight PASS `842f9a62...` |
| P3 假设高度读数 | DONE | 单次进程、冻结 seed 16520261027、12 个标准正态值生成 24 条读数；真值 sidecar 只写入 validator-only 目录 |
| P4 28 项联合反演 | DONE | 单进程、逐次先计费后持久化、4,937 / 12,000 次；账本 31 个任务行（28 拟合 + 2 模型绑定 + 1 终验），28 个估计结果全部封存 |
| P5 封存-评分-报告 | DONE | `SEALED_BEFORE_VALIDATOR`；独立评分、逐起点结果、清单、真实性报告；P5f 即本包 |
| 新增预算 / 改变科研定义的工作 | NOT_STARTED | 合同禁止擅自处理，未申请、未执行 |

## 3. 关键数字（均来自包内文件，可复核）

- 28 任务：FINISHED 23、PARTIAL_SEARCH 5、FAILED 0、BLOCKED 0；`all_reportable_D_null` = True
- 条件计数：NO_HEIGHT 4、H1 12、H10 12（4 颗粒 x [1 基线 + 3 组 sigma=1 nm + 3 组 sigma=10 nm]），F2c 拟合调用合计 4811
- 计费：MODEL_BINDING 94/200、HEIGHT_FITS 4,811/11,200、FINAL_VERIFY 32/600，总 4937/12000 = 41.142%
- attempts 明细 4937 行，状态 {"RETURNED": 4937}；不同参数向量 4468 个，重复向量 101 个
- 计费先于持久化：31/31 任务的 prediction 文件数与账本 used 完全相等；无持久化的 attempt 0 条；模型构造错误调用 0 次
- 生产测试绑定 24 个源码 SHA；测试期内真实 F2c 调用 0 次
- NO_HEIGHT 主设条件组 MAE = 13.054405824607887 nm（4/4 组齐备）
- H1 主设 = **null**：ANON_01 高背景检测 0/3，缺组不得补数；H10 主设 = **null**：ANON_01 仅 1/3
  （已完成子集的描述性 MAE 见 `unified_task_table.json`，标注 DESCRIPTIVE_OPENED_DEVELOPMENT，不作主设结果）
- **ANON_01 未成功检出测径**，本轮不报告其粒径；模拟粒径误差不是实验磁芯绝对测径精度

## 4. 交付物 SHA-256

- estimates.json：`8f97339e9645a29ec929e5c792d234a28821970338cf92a62d2982bfebba7634`
- seal.json：`88b49629f9e4fa6bb943a768108b61d3539ae25af897b280f3e3fcc155023a99`
- verification.json：`cfafbef7171141addd8f99937277e9648fe81a950d7025dd4fdc04eed85d09ad`
- preflight.json：`842f9a625c9704d4e1838c78c72ce522d39f0f946c01b249d22f2449cbc9b11e`
- source_lock.json：`35829be5f23781476754ad0b61d37f793254bb7fd28a5aef55cd3c78aebcb376`
- height_input/height_readings.json（估计器可见）：`bbfd793aff48247623081dd607168cd9afbba2deeff5f37c7a0cbd62b032ad4e`
- p3_height_readings/p3_verification.json：`a0824769b5da1f1dc4753a6198e27723ddf57cedd9f6e0c026124c0ff5ac12a7`
- validator_only/gate_a_003/full_report.json：`71c20b9f112142b6a96a4bc3965d433398c873b8724fc3c6fce112415cc103cf`
- validator_only/gate_a_003/gate_a_receipt.json：`0b2661b1208b098e7515187afacb9f0877b6a1b6292893cb0705f45f5ba8991b`
- validator_only/v166_validator_score.json：`90e0ce25caa71db18f27db29f28dc8efc6cd13c6e8db8cbae3edb5150fb0d8ae`
- validator_only/v166_independent_score.json：`bf29b432e17117c942f20616733a212adc59463f25d89f43c0ae8efac6d9a0e5`
- validator_only/v166_height_truth_sealed.json：`acb3d44cb944d094a19575aaf6ce98da5d619e8318bf0fd00400a9d9c8ebbb06`
- workstation_tests/production_001/test_receipt.json：`ddbaf835969d65660f742d9be217743103deba5800d001e7903b0abe842cffd0`
- p5_report/unified_task_table.json：`6ec092bf14aff48680d267eec8f67cfca6599fb09d344fe44e094966bb282edd`
- p5_report/per_start_results.json：`dd35a7852fa87dc400edd5a488d9df8a0d50a81296bdb45f5b95e10bdf88bf70`
- p5_report/provenance_scenarios_and_images.json：`1a2472ac9c5101f788a2d1ad978202e9caeccaab11a27c290b8c4cb9c0362e01`
- p5_report/budget_summary.json：`fb8433fb4456d6c51c6974f25eb24cdb55e060750b15b02ca3bf0cc087caa7bd`
- p5_report/execution_authenticity.json：`da458024f22cf1e797d6e72fdced6e416395ac13b042be257fdc10fb4a3e881a`
- p5_report/manifest_index.json：`6a6a3b8b3122fa6f3f920e5ac57b3faef18e0348b36f007b1e723f73c3dd9a03`
- deliverables/budget/v166_budget.sqlite（账本副本）：`254b5485164a57865328c81f8890ea4aa458d1386ed6f5f34533f2848f7e4ece`

## 5. 清单与聚合 SHA（对排序后的 "<sha>  <path>换行" 序列取 SHA-256）

- HEAD 全部受版本控制文件（源码、测试与已入库证据）（7477 项）：`5ff3707c0de04fae86dd2701059a4b09545a02ee27ebf8a8829de97b5f775926`
- 全部受版本控制的源码与测试（653 项）：`4f13ff752064918f2d31e20ad7a525f94c219ecb064f32fd0be20c3bb8bc8034`
- 实际调用的执行与测试模块（22 项）：`787b3cbc73ae5238dce00af45ac8e2b788fd7203c4833dec28aa2766b3346fdb`
- 未入库的原始预测数组（4937 项）：`ca1573f7761e0a641130c6875914030be4e30f634d5ac45a4c1b62ec9ca485a3`
- results/ 磁盘全量（含未入库的真值与 validator-only 评分）（10068 项）：`5a8cd8dcb647539700e9e4e488e3a79a73eee855d66e211950efb3a5bc136f40`

## 6. 包内结构

- `code/`：31 个文件 = HEAD 中 `tools/v165_bundle/**` 的 30 个受版本控制文件 + `tools/gate_a.py`，均取自 HEAD，无 `__pycache__`
  其中 22 个是实际调用的执行与测试模块（含 5 个被修复模块与新增故障注入测试），由 §5 的执行束清单登记；其余 9 个是随附材料：V165 合同副本、`README.md`、冻结计划 `config/v165_plan.json`、V165 原 `manifest_sha256.csv`、4 个 `review/` 工件、`test_inventory.json`。冻结计划与随附材料不在执行束清单的 22 项之内，其逐文件 SHA 由 `ZIP_CONTENTS_SHA256.csv` 与 `code_all_tracked` 清单覆盖
- `results/v166/`：全部执行结果与证据（含 `p5_report/`）；`tasks/*/predictions/` 共 4937 个原始预测数组（约 129.9 MB）不入库、不入包，改由 `predictions_manifest_sha256.csv` 逐文件登记
- `results/v165/validator_only/`：真值与 validator-only 评分。估计器全程不可读；本包在封存完成之后才包含它们
- `deliverables/budget/v166_budget.sqlite`：账本字节级副本。实际执行写入的文件名是 `results/v166/logs/v165_budget.sqlite`，原因是复用 V165 执行器（PLAN_ID/OWNER 仍为 v165），未改名以免破坏 SHA 绑定；已记录于真实性报告
- `contract/`：本轮唯一正式科研执行合同原件
- `ZIP_CONTENTS_SHA256.csv`：包内每一个文件的 SHA-256 与字节数（含本 README）

## 7. 未确立 / 限制（与真实性报告一致）

- 未确立：any absolute diameter for ANON_01..ANON_04 (all reportable_D null)
- 未确立：experimental magnetic-core absolute sizing accuracy
- 未确立：validated improvement of H1 or H10 over the no-height baseline; primary group MAE is null for both
- 未确立：an independent replication of the construction count beyond ledger charges and tests
- 未确立：tamper-evident timing; mtime ordering is single-workstation evidence
- 未确立：physical realism of the hypothetical height readings (camera noise independent assumption)
- `results/v166/failures/` 为空：本轮无 fit_failed、无 fit_blocked 任务记录；5 个任务为 PARTIAL_SEARCH（局部优化器达 200 起点上限），全部保留并计入表
- 24 条读数来自 12 次抽样（sigma=1 与 sigma=10 共用同一 eps），不是 24 次独立抽样
- 5 个既有测试模块相对 P0 快照逐字节 IDENTICAL，未修改任何测试；唯一新增测试为 `tools/v165_bundle/tests/test_p1_fault_injections.py`
- 相对 P0 快照共有 6 个 MODIFIED 文件：5 个执行器/门控模块（`tools/gate_a.py`、`v165_guard.py`、`v165_io.py`、`v165_receipts.py`、`v165_run.py`）+ 测试运行器 `tools/v165_bundle/run_workstation_tests.py`（加固真实 F2c 触发线，非测试模块）；6 份 diff 均在 `p5_report/repair_diffs/`，两侧 SHA 均可独立核验
- addendum 只改动 `p5_report/` 下的证据清单；未触碰任何已执行代码、计划、模型、高度读数、估计、封存、账本或评分文件，因此 4,937/12,000 与全部科学结果不变
- 无证据文件被删除或被覆盖；本轮两个作废草稿（真实性报告 v1、返回包 draft1）均改名或移动保留

## 8. 修订历史与包内容变化

- draft3（5,177 项、17,554,204 B、SHA `5f234fe44758136828dfff4d112dcc0431377eb69b650ba4ff1bfb6aee01f558`）在交付前作废：其包内文件集合与本包完全一致，仅 README 对清单覆盖范围的表述需要更正（执行束 22 项 vs `code/` 31 项、`results/v165/` 真值未入库）。同轮构建脚本还修掉一处 Windows 路径转义错误，那一次尝试直接中止、未产出任何文件。draft3 及其 `.sha256` 被移动（未删除）至 `sh/work/superseded/`。
- draft2（5,173 项、17,092,810 B、SHA `dc4024a992f8ee4b2a2c234196cd5767505085cb351e4797ab45dac9cb856c2e`）在交付前作废：P5f addendum 之后 `p5_report/` 内容发生变化，draft2 内的清单与索引已成旧版。draft2 及其 `.sha256` 被移动（未删除）至 `sh/work/superseded/`。
- 返回包 draft1（5,173 项、17,090,210 B、SHA `ea97559e8146f7dd05e72819650cd3434a6a558eb5b65c8bdd7237ccee00cddd`）在交付前作废：其 `README_V166_RETURN.md` 由 ASCII 兜底写入，中文全部退化为问号；且该 README 未登记进 `ZIP_CONTENTS_SHA256.csv`。draft1 及其 `.sha256` 被移动（未删除）至 `sh/work/superseded/`；本包文件内容集合与 draft1 逐文件一致，仅 README 与清单登记不同。
- `execution_authenticity.json` r1 状态 SUPERSEDED_BEFORE_DELIVERY，SHA `4af5d5bbb39754559afb7c926a34e7eb5a2d3e0c6d9264d965f94fbe827c758c`：four attestation fields read wrong keys from the upstream P5 reports (state_counts, start_states, identity-error key, phases key); no evidence file or executed artifact was touched. The draft was not deleted: it was renamed and is retained beside this file as execution_authenticity_r1_superseded.json

本包是本轮交付的唯一返回 ZIP。

## 9. 执行真实性

`results/v166/p5_report/execution_authenticity.json`：19 项声明（ATTESTED 17、ATTESTED_WITH_CAVEAT 2），可读版 `execution_authenticity.md`。两项带保留声明为：控制台输出缓冲导致的 P4 日志截断、账本文件名与合同不一致。

