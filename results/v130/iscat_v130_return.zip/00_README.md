# V130 执行摘要

- 修复 V129 F2 np.empty_like 未初始化累加 bug
- K 重反演（固定 F2 复场前向）：MAE=7.5nm
- 全部 CONDITIONAL/SYNTHETIC；EXPERIMENTAL_ABSOLUTE_DIAMETER_VALIDATED=false
