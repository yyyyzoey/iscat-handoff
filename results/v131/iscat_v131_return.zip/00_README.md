# V131 执行摘要

- 24 例候选（K6+L6+H6+J6），20/24 在 max(5nm,0.1D) 目标内（83.3%）
- V131 包复场前向 + 模板库多起点：显著改善
- K03 +0.2nm / L03 +0.7nm / H05 +0.3nm / H04 +0.2nm
- 4 例超目标集中在 D=63-93 过渡区（如实报告）
- 6 优先剖面完成；F2 复场前向经过 675393 次调用验证
- 全部 CONDITIONAL/SYNTHETIC；EXPERIMENTAL_ABSOLUTE_DIAMETER_VALIDATED=false
