function run_v059_p0_layout_tests(nanobemRoot, outRoot)
% P0 9.1: duffy1/eval2 layout tests for Npair=1,2,3 across modes.
projectRoot='C:\Users\PC\Documents\Codex\2026-09-20\https-chatgpt-com-share-6aafd462-6e70\work\iscat_v0_4';
addpath(fullfile(projectRoot,'src'),fullfile(projectRoot,'config'));
[~,~]=prepare_nanobem(projectRoot,nanobemRoot);
if nargin<2, outRoot=fullfile(projectRoot,'v059_return','p0_layout'); end
if ~isfolder(outRoot), mkdir(outRoot); end
diary(fullfile(outRoot,sprintf('layout_%s.log',newline2tag(nanobemRoot)))); cl=onCleanup(@() diary('off'));
q=trisphere(4,35.5);
mats=[Material(1.5^2,1),Material(1.33^2,1),Material(epstable('gold.dat'),1)];
tau=BoundaryEdge(mats,q,[3,2]);
M=touching(tau,tau); [i1,i2]=find(M);
k1=2*pi/520/1.33;
rows={};
for k=[1,2,3]
  pts=quadduffy(tau(i1(1:k)),tau(i2(1:k)),3,'rows',1);
  obj=galerkin.pot1.duffy1('nduffy',3); obj.pts=pts;
  modes=join(arrayfun(@(x)string(x.mode),pts),'+');
  npair=numel(pts.tau1);
  err='';
  try
    data=eval2(obj,k1);
    sz=mat2str(size(data.SL));
    % independent explicit-index reference for SL (sum over Q per pair)
    % independent explicit scalar-loop reference (no squeeze/dot semantics)
    [pos1,f1,fp1]=eval(pts,1); [pos2,f2,fp2]=eval(pts,2);
    w=pts.w; Q=size(pos1,2);
    ref=zeros(npair,3,3);
    for p=1:npair
      for qq=1:Q
        dv=norm(squeeze(pos1(p,qq,:)-pos2(p,qq,:)));
        Gpq=exp(1i*k1*dv)/(4*pi*dv);
        Fpq=(1i*k1-1/dv)*Gpq;
        for a1=1:3, for a2=1:3
          f1v=squeeze(f1(p,qq,a1,:)); f2v=squeeze(f2(p,qq,a2,:));
          SLpq=Gpq*(dot(double(squeeze(f1v)),double(squeeze(f2v)))-double(fp1(p,qq,a1))*double(fp2(p,qq,a2))/k1^2);
        end, end
      end
    end
    match=max(abs(data.SL(:)-ref(:)));
    rows{end+1}=struct('npair',k,'modes',char(modes),'status','OK','SL_shape',sz, ...
      'ref_max_abs_diff',match,'layout_candidate',strcmp(newline2tag(nanobemRoot),'candidate')); %#ok<AGROW>
    fprintf('[059:p0] npair=%d modes=%s OK SL%s refdiff=%.3g\n',k,modes,sz,match);
  catch ME
    rows{end+1}=struct('npair',k,'modes',char(modes),'status','ERROR', ...
      'error',ME.message,'stack_top',ME.stack(1).name); %#ok<AGROW>
    fprintf('[059:p0] npair=%d modes=%s ERROR: %s @%s\n',k,modes,ME.message,ME.stack(1).name);
    continue;
  end
end
writetable(struct2table([rows{:}]),fullfile(outRoot,sprintf('layout_%s.csv',newline2tag(nanobemRoot))));
end
function s=newline2tag(root)
if contains(root,'p0layout'), s='candidate'; else, s='baseline'; end
end
function d=d0(a,b), d=sqrt(dot(a-b,a-b,3)); end



