function run_v059_r1_axis_sentinel()
% R1: asymmetric sentinel -> freeze axis mapping -> fixed-axis D45 forward recheck.
projectRoot='C:\Users\PC\Documents\Codex\2026-09-20\https-chatgpt-com-share-6aafd462-6e70\work\iscat_v0_4';
addpath(fullfile(projectRoot,'src'),fullfile(projectRoot,'config'));
[~,~]=prepare_nanobem(projectRoot,'');
addpath('C:\Users\PC\Documents\Codex\2026-09-20\https-chatgpt-com-share-6aafd462-6e70\work\iscat_v047_handoff\iSCAT_v047_Codex_handoff\matlab');
outRoot=fullfile(projectRoot,'v059_return','r1_axis');
if ~isfolder(outRoot), mkdir(outRoot); end
diary(fullfile(outRoot,'matlab_run.log')); cl=onCleanup(@() diary('off'));
dc=fullfile(projectRoot,'v058_return','dense_c');
% ---- sentinel: known asymmetric displacement x=+325nm (5 px), y=0
L=load(fullfile(dc,'D44_s_prod576.mat'),'s'); s=L.s;
c=s.cfg; c.focus_nm=[0,0,450]; c.sampling.subpixels=5;
moved=iscat045.translate_normal(s,[325,0]); cm=moved.cfg; cm.focus_nm=[0,0,450];
r=render_system(moved,cm);
L0=load(fullfile(dc,'D44_z450_dense.mat'),'Cm'); % not needed for sentinel; use origin render
r0=render_system(s,c);
dC=r.contrast-r0.contrast;
[~,ir]=max(dC(:)); [rowC,colC]=ind2sub(size(dC),ir);
centerRow=(65+1)/2; centerCol=(65+1)/2;
disp_row=rowC-centerRow; disp_col=colC-centerCol;
fprintf('[059:r1] sentinel: bright-delta displacement row=%d col=%d px (expect ~+5 rows if rows=x)\n',disp_row,disp_col);
if disp_row==5 && abs(disp_col)<=1, map='IDENTITY_ROWS_X'; elseif disp_col==5, map='TRANSPOSE'; else, map='AMBIGUOUS'; end
fprintf('[059:r1] sentinel mapping: %s\n',map);
% ---- model side: predict same sentinel via dense model
slices={}; Z=(350:25:600);
for D=[44,46], for z=Z
  slices{end+1}=fullfile(dc,'slices',sprintf('slice_D%d_z%d.mat',D,z)); %#ok<AGROW>
end, end
modelFile=fullfile(outRoot,'models_dense_2node.mat');
if isfile(modelFile), M=load(modelFile,'models'); models=M.models; else, models=ASSEMBLE_MAPS047(slices,modelFile); end
ctx=iscat047.prepare_model(models.C);
cx0=33; ix0=(cx0-20):(cx0+20);
xr=r.x_nm(ix0); yr=r.y_nm(ix0);
Ps=iscat047.predict(ctx,[44,450,325,0],xr,yr); % ROI query
dP=Ps-r0.contrast(ix0,ix0);
[~,irP]=max(dP(:)); [rowP,colP]=ind2sub(size(dP),irP);
centerRoi=21;
fprintf('[059:r1] model sentinel: displacement row=%d col=%d within ROI (map rows=x)\n',rowP-centerRoi,colP-centerRoi);
axis_contract=struct('schema','iscat059.axis_contract.1', ...
  'observation_rows','camera_x (render_system convention, es flipped along dim1)', ...
  'observation_cols','camera_y', ...
  'model_rows','map_x_nm (griddedInterpolant first grid dim)', ...
  'model_cols','map_y_nm', ...
  'frozen_mapping','IDENTITY (no transpose) between iscat047.predict output and truth observation', ...
  'sentinel_evidence',struct('truth_disp_row_px',disp_row,'truth_disp_col_px',disp_col, ...
  'model_disp_row_px',rowP-centerRoi,'model_disp_col_px',colP-centerRoi), ...
  'forbidden','min(rel,rel_transposed) as formal metric; per-case direction choice', ...
  'frozen_at','2026-10-11');
iscat047_write=jsonencode(axis_contract);
fid=fopen(fullfile(outRoot,'axis_contract.json'),'w'); fwrite(fid,iscat047_write); fclose(fid);
% ---- fixed-axis D45 forward recheck with numerators/denominators + residual save
truthT='C:\Users\PC\Documents\Codex\2026-09-20\https-chatgpt-com-share-6aafd462-6e70\work\iscat_v0_4\v056_return\s5_truth';
cx=33; ix=(cx-20):(cx+20);
res={};
for z=[450,550]
  L=load(fullfile(truthT,sprintf('D45_z%d_truth',z),'truth_private.mat'),'truth');
  O=L.truth.C; Oroi=O(ix,ix);
  P=iscat047.predict(ctx,[45,z,8.45,-24.05],r.x_nm(ix),r.y_nm(ix)); Proi=P;
  num=norm(Proi(:)-Oroi(:)); den=norm(Oroi(:)); rel=num/den;
  relT=norm(P'-Oroi)/den;
  res{end+1}=struct('z',z,'numerator',num,'denominator',den,'relL2',rel, ...
    'relT_diagnostic_only',relT,'gate2pct',rel<0.02,'mapping',map); %#ok<AGROW>
  save(fullfile(outRoot,sprintf('D45_z%d_residuals.mat',z)),'P','O','ix','-v7.3');
  fprintf('[059:r1] D45 z=%d FIXED-AXIS relL2=%.4f (num=%.4f den=%.4f) diagT=%.4f gate=%d\n',z,rel,num,den,relT,rel<0.02);
end
writetable(struct2table([res{:}]),fullfile(outRoot,'fixed_axis_forward_checks.csv'));
end


