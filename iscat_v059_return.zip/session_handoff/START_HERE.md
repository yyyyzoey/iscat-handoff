# START_HERE
当前工程根目录（不要用其它路径）：
C:\Users\PC\Documents\Codex\2026-09-20\https-chatgpt-com-share-6aafd462-6e70\work\iscat_v0_4

最短启动：
1. 读本目录 PROJECT_STATE.json 与 DECISIONS.md；
2. 生产脚本在 src\，配置在 config\iscat_config.m；
3. 库加载统一走 src\prepare_nanobem.m（pin ce49f77f096337db8be54c46d83696d37b0b23d5）；
4. rule7 诊断用候选库 third_party_candidates\nanobem-iscat052-rule7candidate（仅 refine2.m 有补丁）；
5. 本轮（v055）只做了证据恢复与矩阵复核，未运行新的 BEM 求解；
6. 下一步见 NEXT_STEP.md；任务清单见 TASKS.csv。
